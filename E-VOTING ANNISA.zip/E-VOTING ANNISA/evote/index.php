<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Pemilihan Ketua OSIS</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  
  <script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/data.js"></script>
<script src="https://code.highcharts.com/modules/drilldown.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>
<script src="https://code.highcharts.com/modules/accessibility.js"></script>

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Ninestars - v4.7.0
  * Template URL: https://bootstrapmade.com/ninestars-free-bootstrap-3-theme-for-creative/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between">

      <div class="logo">
        <h1 class="text-light"><a href="index.html"><span>E-Vote</span></a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="#cek_pemilih">Cek Pemilih</a></li>
          <li><a class="nav-link scrollto" href="#kandidat">Kandidat</a></li>
          <li><a class="nav-link scrollto" href="#cara_pilih">Cara Pemilihan</a></li>
          <li><a class="nav-link scrollto" href="#hasil">Hasil</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center" style="height: 550px">

    <div class="container">
      <div class="row gy-4">
        <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center">
          <h1>Elektronik Voting</h1>
          <h2>Sistem Pemilihan Ketua OSIS SMA Negeri 1 Warung Kiara periode Tahun 2022-2023</h2>
          <div>
            <a href="#cek_pemilih" class="btn-get-started scrollto">Cek Data Pemilih</a>
          </div>
        </div>
        <div class="col-lg-6 order-1 order-lg-2 hero-img">
          <img src="assets/img/vote.png" class="img-fluid animated" alt="">
        </div>
      </div>
    </div>

  </section><!-- End Hero -->

  <main id="main">
    <!-- ======= Contact Us Section ======= -->
    <section id="cek_pemilih" class="contact">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <p>CEK DATA PEMILIH</p>
        </div>

        <div class="row">

          
          <div class="col-lg-6 order-1 order-lg-2 text-center">
           <img src="assets/img/cari.png" class="img-fluid animated" alt="" width="170px">
          </div>

          <div class="col-lg-6 mt-5 align-items-stretch" data-aos="fade-up" data-aos-delay="200">
            <p>Untuk melakukan pengecekan daftar data pemilih pada pemilihan Ketua OSIS SMA Negeri 1 Warung Kiara periode Tahun 2022-2023, silahkan masukan NIS anda kemudian klik button cari. Jika data anda tidak terdaftar, segera hubungu PPS anda masing-masing.</p><br>
            <form action="cek_pemilih.php" method="POST" role="form">
              <div class="row">
                <div class="form-group col-lg-9">
                  <input type="number" name="nis" class="form-control" required placeholder="Masukan NIS">
                </div>
                <div class="form-group col-lg-3">
                <div class="text-center"><button type="submit" class="btn btn-primary" style="color: white; background-color: #EB5D1E; border-radius: 60px; margin-left: 25px; margin-right: 25px; width: 100px">Cari</button></div>
                </div>
              </div>
            </form>
          </div>

        </div>
      </div>

      </div>
    </section><!-- End Contact Us Section -->

    <!-- ======= Services Section ======= -->
    <section id="kandidat" class="services section-bg" style="margin-top: 0px">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>KANDIDAT</h2>
          <p style="font-size: 19px">Calon Ketua dan Wakil Ketua OSIS Periode 2023-2024</p>
        </div>

        <div class="row">

        <?php
          include 'config/koneksi.php';
          $sql = "SELECT * FROM `kandidat`";
          $data = mysqli_query($db,$sql);      
          while($tampil = mysqli_fetch_array($data)){
        ?>

          <div class="col-lg-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-box">
                  <h4 class="title"><a href="">No. <?php echo $tampil['nomor_urut']?></a></h4>
                  <div class="icon"><img src="assets/img/team/<?php echo $tampil['foto']?>" height="210px"></div>
                  
                  <p class="description"><b><?php echo $tampil['nama']?></b></p>
                  <p class="description">(<?php echo $tampil['nis']?>)</p>
                  <p class="description"><b>Kelas : </b><?php echo $tampil['kelas']?></p>
                  <p align="left"><b>Visi :</b> <?php echo $tampil['visi']?></p>
                  <p align="left"><b>Misi :<br></b> <?php echo $tampil['misi']?></p>
                
            </div>
          </div>

        <?php } ?>

        </div>

      </div>
    </section><!-- End Services Section -->

    <!-- ======= About Section ======= -->
    <section id="cara_pilih" class="about">
      <div class="container">

        <div class="row justify-content-between">
          <div class="col-lg-12 pt-5 pt-lg-0">
            <h3 data-aos="fade-up">Alur Pemilihan Ketua OSIS</h3>
            <p data-aos="fade-up" data-aos-delay="100">
              Berikut alur dan tata cara pelaksanaan pemilihan ketua OSIS dengan platform digital E-VOTE.
            </p>
            <div class="row">
              <div class="col-md-6" data-aos="fade-up" data-aos-delay="100">
                <i class="bx bx-receipt"></i>
                <h4>Sebelum Pemilihan</h4>
                <p>- Pastikan anda sudah terdaftar sebagai pemilih, <br>- Pada masa pemutakhiran data, pastikan anda menerima email token verifikasi dan pemutakhiran data pemilih, <br>- Klik link dan token yang dikirmkan hingga muncul halaman "Akun anda berhasil diaktivasi", <br>- Selalu cek bertahap data pemilih anda. <br></p>
              </div>
              <div class="col-md-6" data-aos="fade-up" data-aos-delay="200">
                <i class="bx bx-cube-alt"></i>
                <h4>Saat Pemilihan</h4>
                <p>- Setelah TPS dinyatakan dibuka, pastikan anda menerima email token Surat Suara, <br>- Klik link dan token yang dikirimkan hingga muncul halaman "Bilik Suara / Surat Suara DIgital", <br>- Pilih salah satu kandidat. <br></p>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End About Section -->

    <!-- ======= Services Section ======= -->
    <section id="hasil" class="services section-bg">
      <div class="container" data-aos="fade-up">

        <div class="row">
          <?php
            include "config/koneksi.php";
            $sql = "SELECT * FROM `setting`";
            $data = mysqli_query($db,$sql);      
            $tampil = mysqli_fetch_array($data);

            if ($tampil['status_tps']=='Sudah Ditutup') {
          ?>

            <div class="section-title">
              <p style="font-size: 19px">Rekapitulasi Suara</p>
            </div>

            <figure class="highcharts-figure">
              <div id="container"></div>
            </figure>
          <?php
            }elseif ($tampil['status_tps']=='Belum Dibuka'){
              ?>
                <div class="container">
                  <div class="row">
                    <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center">
                      <h1>Uppsss,</h1>
                      <h4>TPS belum dibuka dan pemilihan belum dimulai, hasil pemilihan akan tampil setelah TPS ditutup dan pemilihan telah dinyatakan selesai.</h4>
                    </div>
                    <div class="col-lg-6 order-1 order-lg-2  text-center">
                      <img src="assets/img/hmm.png" class="img-fluid animated" alt="" width="170px">
                    </div>
                  </div>
                </div>
              <?php
            }elseif ($tampil['status_tps']=='Dibuka'){
              ?>
                <div class="container">
                  <div class="row">
                    <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center">
                      <h1>Hmmmsss,</h1>
                      <h4>TPS sedang dibuka dan pemilihan sedang berlangsung, hasil pemilihan akan tampil setelah TPS ditutup dan pemilihan telah dinyatakan selesai.</h4>
                    </div>
                    <div class="col-lg-6 order-1 order-lg-2  text-center">
                      <img src="assets/img/hmm.png" class="img-fluid animated" alt="" width="170px">
                    </div>
                  </div>
                </div>
              <?php
            }
          ?>
        
        </div>

      </div>
    </section><!-- End Services Section -->


  <script type="text/javascript">
    Highcharts.chart('container', {
  chart: {
    type: 'column'
  },
  title: {
    align: 'left',
    text: 'Hasil Rekapitulasi Suara'
  },
  subtitle: {
    align: 'left',
    text: 'Pemilihan Ketua OSIS SMA XYZ Tahun 2022'
  },
  accessibility: {
    announceNewData: {
      enabled: true
    }
  },
  xAxis: {
    type: 'category'
  },
  yAxis: {
    title: {
      text: '-'
    }

  },
  legend: {
    enabled: false
  },
  plotOptions: {
    series: {
      borderWidth: 0,
      dataLabels: {
        enabled: true,
        format: '{point.y:.1f}%'
      }
    }
  },

  tooltip: {
    headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
    pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}%</b>'
  },

  series: [
    {
      name: "Jumlah Suara",
      colorByPoint: true,
      data: [
      <?php
        $sql8 = "SELECT COUNT(nomor_urut) as jml8 FROM `kotak_suara` where kode_pilih!='0';";
        $data8 = mysqli_query($db, $sql8);
        $tampil8 = mysqli_fetch_array($data8);

        $jml8 = $tampil8['jml8'];
        $sql9 = "SELECT a.nomor_urut, b.nama, COUNT(a.nomor_urut) as jml3 FROM `kotak_suara` as a inner join kandidat as b on a.nomor_urut=b.nomor_urut group by a.nomor_urut order by b.nomor_urut;";
        $data9 = mysqli_query($db, $sql9);
        while($tampil9 = mysqli_fetch_array($data9)){
      ?>
        {
          name: "<?php echo $tampil9['nama'] ?>",
          y: <?php $jml3 = $tampil9['jml3']; $persen = $jml3 / $jml8 * 100; echo $persen; ?>,
          drilldown: "<?php echo $tampil9['nama'] ?>"
        },
      <?php
        }
      ?>
      ]
    }
  ],
  drilldown: {
    breadcrumbs: {
      position: {
        align: 'right'
      }
    },
    series: [
      {
        name: "Chrome",
        id: "Chrome",
        data: [
          [
            "v65.0",
            0.1
          ],
          [
            "v64.0",
            1.3
          ],
          [
            "v63.0",
            53.02
          ],
          [
            "v62.0",
            1.4
          ],
          [
            "v61.0",
            0.88
          ],
          [
            "v60.0",
            0.56
          ],
          [
            "v59.0",
            0.45
          ],
          [
            "v58.0",
            0.49
          ],
          [
            "v57.0",
            0.32
          ],
          [
            "v56.0",
            0.29
          ],
          [
            "v55.0",
            0.79
          ],
          [
            "v54.0",
            0.18
          ],
          [
            "v51.0",
            0.13
          ],
          [
            "v49.0",
            2.16
          ],
          [
            "v48.0",
            0.13
          ],
          [
            "v47.0",
            0.11
          ],
          [
            "v43.0",
            0.17
          ],
          [
            "v29.0",
            0.26
          ]
        ]
      },
      {
        name: "Firefox",
        id: "Firefox",
        data: [
          [
            "v58.0",
            1.02
          ],
          [
            "v57.0",
            7.36
          ],
          [
            "v56.0",
            0.35
          ],
          [
            "v55.0",
            0.11
          ],
          [
            "v54.0",
            0.1
          ],
          [
            "v52.0",
            0.95
          ],
          [
            "v51.0",
            0.15
          ],
          [
            "v50.0",
            0.1
          ],
          [
            "v48.0",
            0.31
          ],
          [
            "v47.0",
            0.12
          ]
        ]
      },
      {
        name: "Internet Explorer",
        id: "Internet Explorer",
        data: [
          [
            "v11.0",
            6.2
          ],
          [
            "v10.0",
            0.29
          ],
          [
            "v9.0",
            0.27
          ],
          [
            "v8.0",
            0.47
          ]
        ]
      },
      {
        name: "Safari",
        id: "Safari",
        data: [
          [
            "v11.0",
            3.39
          ],
          [
            "v10.1",
            0.96
          ],
          [
            "v10.0",
            0.36
          ],
          [
            "v9.1",
            0.54
          ],
          [
            "v9.0",
            0.13
          ],
          [
            "v5.1",
            0.2
          ]
        ]
      },
      {
        name: "Edge",
        id: "Edge",
        data: [
          [
            "v16",
            2.6
          ],
          [
            "v15",
            0.92
          ],
          [
            "v14",
            0.4
          ],
          [
            "v13",
            0.1
          ]
        ]
      },
      {
        name: "Opera",
        id: "Opera",
        data: [
          [
            "v50.0",
            0.96
          ],
          [
            "v49.0",
            0.82
          ],
          [
            "v12.1",
            0.14
          ]
        ]
      }
    ]
  }
});
  </script>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="container py-4">
      <div class="copyright">
        Nisa Teknik Informatika 2018
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/ninestars-free-bootstrap-3-theme-for-creative/ -->
        Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>