<?php                 
  include 'config/koneksi.php';
                $nis=$_POST['nis'];
                  
                    $sql_cek=mysqli_query($db,"SELECT * FROM data_pemili as a inner join surat_suara as b on a.nis = b.nis WHERE a.nis='".$nis."'") or die(mysqli_error($db));
                    $r_cek=mysqli_fetch_array($sql_cek);
                    $jml_data=mysqli_num_rows($sql_cek);
          
                    if ($jml_data>0) {
                         header("Location: notifikasi.php?p=$nis");
                         }else{
                          //data tidak di temukan
                           header("Location: notifikasi.php?p=97");
                         }
                      
                    
                  ?>