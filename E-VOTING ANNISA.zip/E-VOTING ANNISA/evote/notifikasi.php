<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Pemilihan Ketua OSIS</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  
  <script src="https://code.jquery.com/jquery-3.1.0.js"></script>
  <script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Ninestars - v4.7.0
  * Template URL: https://bootstrapmade.com/ninestars-free-bootstrap-3-theme-for-creative/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>
  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between">

      <div class="logo">
        <h1 class="text-light"><a href="index.php"><span>E-Vote</span></a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto" href="index.php">Home</a></li>
          <li><a class="nav-link scrollto" href="index.php">Cek Pemilih</a></li>
          <li><a class="nav-link scrollto" href="index.php">Kandidat</a></li>
          <li><a class="nav-link scrollto" href="index.php">Cara Pemilihan</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->
  
  <main id="main">

    <!-- ======= Contact Us Section ======= -->
    <section id="hero" class="d-flex align-items-center" style="margin-bottom: 0px;">
      <div class="container" data-aos="fade-up">

        <div class="row">

        <?php
          $p = $_GET['p'];

          if ($p == '1') {
        ?>
          <div class="container">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center">
                <h1>Terima Kasih,</h1>
                <h4>Kamu sudah memberikan hak suaramu pada pemilihan Ketua OSIS SMA Negeri 1 Warung Kiara periode Tahun 2022-2023</h4>
              </div>
              <div class="col-lg-6 order-1 order-lg-2  text-center">
                <img src="assets/img/sudah_milih.png" class="img-fluid animated" alt="" width="200px">
              </div>
            </div>
          </div>
        <?php
          }elseif ($p == '2') {
        ?>
          <div class="container">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center">
                <h1>Data Mutakhir,</h1>
                <h4>Selamat kamu sudah terdaftar sebagai pemilih tetap dan berhak memberikan suaramu pada pemilihan Ketua OSIS SMA Negeri 1 Warung Kiara periode Tahun 2022-2023</h4>
              </div>
              <div class="col-lg-6 order-1 order-lg-2  text-center">
                <img src="assets/img/mtakhir.png" class="img-fluid animated" alt="" width="420px">
              </div>
            </div>
          </div>
        <?php
          }elseif ($p == '3') {
        ?>
          <div class="container">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center">
                <h1>Uppsss,</h1>
                <h4>Pemutakhiran data pemilih gagal diproses, silahkan ulangi lagi dengan klik token yang dikirim melalui email sebelumnya !</h4>
              </div>
              <div class="col-lg-6 order-1 order-lg-2  text-center">
                <img src="assets/img/Ups.png" class="img-fluid animated" alt="" width="300px">
              </div>
            </div>
          </div>
        <?php
          }elseif ($p == '0') {
        ?>
          <div class="container">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center">
                <h1>Uppsss,</h1>
                <h4>Suara kamu gagal diproses, silahkan ulangi lagi dengan klik token yang dikirim melalui email sebelumnya !</h4>
              </div>
              <div class="col-lg-6 order-1 order-lg-2  text-center">
                <img src="assets/img/Ups.png" class="img-fluid animated" alt="" width="300px">
              </div>
            </div>
          </div>
        <?php
          }elseif ($p == '98') {
        ?>
          <div class="container">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center">
                <h1>Hmmsss,</h1>
                <h4>Kamu sebelumnya sudah melakukan pemutakhiran data pemilih dengan klik link yang sama, dan kamu sudah terdaftar sebagai pemilih tetap.</h4>
              </div>
              <div class="col-lg-6 order-1 order-lg-2  text-center">
                <img src="assets/img/hmm.png" class="img-fluid animated" alt="" width="170px">
              </div>
            </div>
          </div>
        <?php
          }elseif ($p == '99') {
        ?>
          <div class="container">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center">
                <h1>Hmmsss,</h1>
                <h4>Kamu sebelumnya sudah memberikan hak suara dengan klik link yang sama.</h4>
              </div>
              <div class="col-lg-6 order-1 order-lg-2  text-center">
                <img src="assets/img/hmm.png" class="img-fluid animated" alt="" width="170px">
              </div>
            </div>
          </div>
        <?php
          }elseif ($p == '97') {
        ?>
          <div class="container">
            <div class="row">
              <div class="col-lg-8 order-2 order-lg-1 d-flex flex-column justify-content-center">
                <h1>Pemilih Tidak Terdaftar,</h1>
                <h4>Kamu tidak terdaftar sebagai pemilih pada pemilihan Ketua OSIS SMA Negeri 1 Warung Kiara periode Tahun 2022-2023</h4>
              </div>
              <div class="col-lg-4 order-1 order-lg-2  text-center">
                <img src="assets/img/Ups.png" class="img-fluid animated" alt="" width="300px">
              </div>
            </div>
          </div>
        <?php
          }elseif ($p == '65') {
        ?>
          <div class="container">
            <div class="row">
              <div class="col-lg-8 order-2 order-lg-1 d-flex flex-column justify-content-center">
                <?php 
                  include 'config/koneksi.php';
                  $sql = "SELECT * FROM `setting`";
                  $data = mysqli_query($db,$sql);      
                  $tampil = mysqli_fetch_array($data);
                ?>
                <h1>Hmmsss, TPS Belum Dibuka</h1><br> 
                <h4>TPS akan segera dibuka pada <?php echo $tampil['waktu_buka'];?> s/d <?php echo $tampil['waktu_tutup'];?>.</h4>
              </div>
              <div class="col-lg-4 order-1 order-lg-2 text-center">
                <img src="assets/img/hmm2.png" class="img-fluid animated" alt="" width="170px">
              </div>
            </div>
          </div>
        <?php
          }elseif ($p == '66') {
        ?>
          <div class="container">
            <div class="row">
              <div class="col-lg-8 order-2 order-lg-1 d-flex flex-column justify-content-center">
                <?php 
                  include 'config/koneksi.php';
                  $sql = "SELECT * FROM `setting`";
                  $data = mysqli_query($db,$sql);      
                  $tampil = mysqli_fetch_array($data);
                ?>
                <h1>Hmmsss, TPS Sudah Tutup</h1><br> 
                <h4>TPS dibuka pada <?php echo $tampil['waktu_buka'];?> s/d <?php echo $tampil['waktu_tutup'];?>.</h4>
              </div>
              <div class="col-lg-4 order-1 order-lg-2 text-center">
                <img src="assets/img/hmm2.png" class="img-fluid animated" alt="" width="170px">
              </div>
            </div>
          </div>
        <?php
          }else {
        ?>
          <div class="container">
            <div class="row">
              <div class="col-lg-8 order-2 order-lg-1 d-flex flex-column justify-content-center">
                <?php                 
                  include 'config/koneksi.php';
                  $nis=$p;
                  
                    $sql_cek=mysqli_query($db,"SELECT * FROM data_pemili as a inner join surat_suara as b on a.nis = b.nis WHERE a.nis='".$nis."'") or die(mysqli_error($db));
                    $r_cek=mysqli_fetch_array($sql_cek);
                  ?>
                <h1>Pemilih Sudah Terdaftar,</h1><br> 
                <h4>Nama : <?php echo $r_cek['nama'];?><br>NIS : <?php echo $r_cek['nis'];?><br>Kelas : <?php echo $r_cek['kelas'];?><br><br> Kamu sudah terdaftar sebagai pemilih pada pemilihan Ketua OSIS SMA Negeri 1 Warung Kiara periode Tahun 2022-2023</h4>
              </div>
              <div class="col-lg-4 order-1 order-lg-2 text-center">
                <img src="assets/img/yey.png" class="img-fluid animated" alt="" width="170px">
              </div>
            </div>
          </div>
        <?php
          }
        ?>
      </div>
      </div>
    </section><!-- End Services Section -->

  </main>

     <!-- ======= Footer ======= -->
  <footer id="footer" style="background-color: white">

    <div class="container py-4">
      <div class="copyright">
        Nisa Teknik Informatika 2018
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/ninestars-free-bootstrap-3-theme-for-creative/ -->
        Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="js/jquery-3.1.0.js"></script>
  <script src="js/jquery.dataTables.min.js"></script>
  <script>
    $(document).ready(function(){
        $('#tabel-data').DataTable();
    });
  </script>
  <script src="assets/js/main.js"></script>

</body>

</html>