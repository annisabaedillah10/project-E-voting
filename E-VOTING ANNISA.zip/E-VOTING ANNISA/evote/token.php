function getToken($val){
 $token = password_hash($val, PASSWORD_DEFAULT);
 return $token;
}
 
echo getToken('juhdirosadi14@gmail.com');
echo getToken('juhdi.rosadi@nusaputra.a');