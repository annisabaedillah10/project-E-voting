<?php
	include "config/koneksi.php";

	$token=$_GET['t'];

	$sql_cek=mysqli_query($db,"SELECT * FROM surat_suara WHERE token='".$token."' and keterangan='mutakhir' OR token='".$token."' and keterangan='sudah memilih'");
	$jml_data=mysqli_num_rows($sql_cek);

	if ($jml_data=='1') {
		header("Location: notifikasi.php?p=98");
	}else{
		$sql = "UPDATE `surat_suara` SET keterangan = 'mutakhir' where token='$token'";
		$data = mysqli_query($db,$sql);

		if ($data) {
		header("Location: notifikasi.php?p=2");
		}else{
			header("Location: notifikasi.php?p=3");
		}
	}
?>