<?php
	include "../config/koneksi.php";

	$nis=$_GET['n'];

	$sql = "UPDATE `surat_suara` SET keterangan = 'tidak mutakhir' where nis='$nis'";
	$data = mysqli_query($db,$sql);

	if ($data) {
	    header("Location: pemutakhiran_data_pemilih.php?p=1");
	}else{
		header("Location: pemutakhiran_data_pemilih.php?p=0");
	}
?>