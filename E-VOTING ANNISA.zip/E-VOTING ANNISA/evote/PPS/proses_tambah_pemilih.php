<?php
	include "../config/koneksi.php";

	$nis=$_POST['nis'];
	$nama=$_POST['nama'];
    $kelas=$_POST['kelas'];
    $jenis_kelamin=$_POST['jenis_kelamin'];
    $email=$_POST['email'];

	$sql_cek=mysqli_query($db,"SELECT * FROM data_pemili WHERE nis='".$nis."'");
    $jml_data=mysqli_num_rows($sql_cek);

    if ($jml_data=='1') {
        header("Location: notifikasi.php?n=$nis");    	
    }else{
    	$tambah_pemilih = mysqli_query($db,"INSERT INTO `data_pemili` (`nis`, `nama`, `jenis_kelamin`, `kelas`, `email`) VALUES ('$nis','$nama','$jenis_kelamin','$kelas','$email')");

        if ($tambah_pemilih) {
            $sql = mysqli_query($db,"INSERT INTO `surat_suara` (`kode_surat_suara`, `nis`, `token`, `keterangan`) VALUES (NULL,'$nis','a','terdaftar')");

            header("Location: pemilih.php");
        }else{
            header("Location: notifikasi.php?n=$nis");
        }
    }
?>