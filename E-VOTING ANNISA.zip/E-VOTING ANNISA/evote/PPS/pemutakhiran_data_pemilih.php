<?php include 'header.php'; ?>

    <!-- ======= Services Section ======= -->
    <section id="services" class="services section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Pemutakhiran Data Pemilih</h2>
          <p style="font-size: 19px">Pemilihan Ketua OSIS Periode 2023-2024</p>
          <a href="email_mutakhir.php" class="btn btn-primary">Kirim Email Verifikasi</a> <br>
        </div>

          <div class="table-responsive">
            <?php 
              $pesan = isset($_GET['p']) ? $_GET['p'] : '';

              if ($pesan=='1') {
            ?> <div class="alert alert-success"><b>Berhasil,</b> keterangan berhasil diubah !</div>
            <?php
               }elseif ($pesan=='0') {
            ?> <div class="alert alert-danger"><b>Gagal,</b> Keterangan belum berubah !</div>
            <?php
               }else{

               }
              ?>
            
            <table id="tabel-data" class="table table-striped table-bordered" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th>No.</th>
                  <th>NIS</th>
                  <th>Nama</th>
                  <th>Kelas</th>
                  <th>Email</th>
                  <th>Keterangan</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                 <?php
                    $nomor=0;
                    $sql = "SELECT * FROM `data_pemili` as a inner join surat_suara as b on a.nis=b.nis order by b.keterangan DESC";
                    $data = mysqli_query($db,$sql);      
                    while($tampil = mysqli_fetch_array($data)){
                  ?>

                  <tr>
                    <td><?php echo $nomor = $nomor + 1; ?></td>
                    <td><?php echo $tampil['nis']?></td>
                    <td><?php echo $tampil['nama']?></td>
                    <td><?php echo $tampil['kelas']?></td>
                    <td><?php echo $tampil['email']?></td>
                    <td><?php echo $tampil['keterangan']?></td>
                    <td><a href="kirim_token_verif.php?nis=<?php echo $tampil['nis']?>" class="btn btn-warning"><i class="bx bx-envelope" style="color: white"></i></a> <a href="kirim_token_pilih.php?nis=<?php echo $tampil['nis']?>" class="btn btn-success"><i class="bx bx-envelope" style="color: white"></i></a></td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>

      </div>
    </section><!-- End Services Section -->

 
<?php include 'footer.php'; ?>