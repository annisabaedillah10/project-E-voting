<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require "../vendor/autoload.php";
$mail = new PHPMailer(true);
$mail->SMTPDebug = 0;
$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->SMTPAuth = true;
//ganti dengan email dan password yang akan di gunakan sebagai email pengirim
$mail->Username = 'annisa.baedillah_ti18@nusaputra.ac.id';
$mail->Password = '223344ab';
$mail->SMTPSecure = 'ssl';
$mail->Port = 465;
//ganti dengan email yg akan di gunakan sebagai email pengirim
$mail->setFrom('annisa.baedillah_ti18@nusaputra.ac.id', 'Panitia Pemungutan Suara');
$mail->addAddress($tampil2['email'], $tampil2['nama']);
$mail->isHTML(true);
$nama = $tampil2['nama'];
$mail->Subject = "SURAT SUARA";
$mail->Body = "Halo $nama, anda mendapat undangan untuk melakukan voting pemilihan ketua OSIS, untuk memilih silahkan klik link dibawah ini.<br>
 <a href='http://localhost/evote/bilik_suara.php?t=".$token."'>http://localhost/evote/bilik_suara.php?t=".$token."</a> atau <a href='http://192.168.61.102/evote/bilik_suara.php?t=".$token."'>http://192.168.61.102/evote/bilik_suara.php?t=".$token."</a>  <br><br><br>Pemilihan ditutup pada $waktu_tutup";
$mail->send();



