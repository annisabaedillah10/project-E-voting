<?php                 
              include "../config/koneksi.php";
                
                  $nis=$_POST['nis'];
                  $password=$_POST['password'];

                        if(!filter_var($nis, FILTER_VALIDATE_INT)) {  
                          echo("Bukan tipe Integer");  
                         } else { 
                        //cek user terdaftar dan aktif
                         $sql_cek=mysqli_query($db,"SELECT * FROM pps WHERE nis='".$nis."' AND password='".$password."'") or die(mysqli_error($db));
                         $r_cek=mysqli_fetch_array($sql_cek);
                         $jml_data=mysqli_num_rows($sql_cek);
                         if ($jml_data>0) {
                          //buat session login dan redirect ke halaman utama
                          session_start();
                          $_SESSION['status'] = "loginpps";
                          $_SESSION['nis']=$r_cek['nis'];
                          $_SESSION['jabatan']=$r_cek['jabatan'];
                           header("Location:index.php");
                         }else{
                          //data tidak di temukan
                           echo "<script>window.alert('LOGIN GAGAL ! NIS atau Password salah.');
                            window.location=(href='login.php')</script>";
                         }
                      }
                  ?>