<?php
    include "../config/koneksi.php";

    $nis=$_POST['nis'];
    $nama=$_POST['nama'];
    $kelas=$_POST['kelas'];
    $jenis_kelamin=$_POST['jenis_kelamin'];
    $email=$_POST['email'];


        $ubah_pemilih = mysqli_query($db,"UPDATE `data_pemili` SET `nama` = '$nama', `jenis_kelamin` = '$jenis_kelamin', `kelas`='$kelas', `email`='$email' where nis = $nis");

        if ($ubah_pemilih) {
            header("Location: pemilih.php");
        }else{
            header("Location: notifikasi.php?p=0");
        }
?>