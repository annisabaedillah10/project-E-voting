 <?php include 'header.php'; ?>

  <!-- ======= Contact Us Section ======= -->
    <section id="contact" class="contact">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <p>FORM UBAH FOTO KANDIDAT</p>
        </div>

        <div class="row">

          <div class="col-lg-3 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
            
          </div>
          <?php
            include '../config/koneksi.php';
            $nis = $_GET['nis'];
            $sql = "SELECT * FROM `kandidat` where nis = '$nis'";
            $data = mysqli_query($db, $sql);
            $tampil = mysqli_fetch_array($data);
          ?>

          <div class="col-lg-6 mt-5 mt-lg-0 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="200">
            <form action="proses_ubah_foto_kandidat.php" method="post" role="form" enctype="multipart/form-data">
              <div class="row">
                <div class="form-group col-md-6">
                  <label for="name" style="margin-top: 15px">Nama</label>
                  <input type="text" name="nama" class="form-control" required value="<?php echo($tampil['nama']) ?>"  readonly>
                </div>
                <div class="form-group col-md-3">
                  <label for="name" style="margin-top: 15px">NIS</label>
                  <input type="number" name="nis" class="form-control" required value="<?php echo($tampil['nis']) ?>" readonly>
                </div>
                <div class="form-group col-md-3">
                  <label for="name" style="margin-top: 15px">Nomor Urut</label>
                  <input class="form-control" type="number" id="name" name="nomor_urut" value="<?php echo($tampil['nomor_urut']) ?>"  readonly>
                </div>
                <div class="form-group col-md-12">
                  <label for="name" style="margin-top: 15px">Foto</label>
                  <input class="form-control" type="file" id="name" name="file" required="">
                </div>
              <div class="text-center" style="margin-top: 15px"><button type="submit" class="btn btn-primary" style="color: white; background-color: #EB5D1E; border-radius: 60px; margin-left: 25px; margin-right: 25px">SIMPAN</button></div>
            </form>
          </div>

        </div>

      </div>
    </section><!-- End Contact Us Section -->

<?php include 'footer.php'; ?>