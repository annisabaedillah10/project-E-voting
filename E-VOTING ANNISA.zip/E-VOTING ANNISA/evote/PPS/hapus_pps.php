<?php
include '../config/koneksi.php';
$nis = $_GET['n'];

    $sql = "DELETE from `pps` where nis='$nis'";
    $query = mysqli_query($db, $sql);
    if ($query) {
        echo "<script>window.alert('Berhasil menghapus data pps');
        window.location=(href='pps.php')</script>";
    } else {
        echo "<script>window.alert('Gagal, ada kesalahan saat menghapus data pps di dalam database');
		window.location=(href='pps.php')</script>";
    }