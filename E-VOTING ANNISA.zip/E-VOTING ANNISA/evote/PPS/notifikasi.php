<?php include 'header.php'; ?>
<!-- ======= Services Section ======= -->
  <section id="hero" class="d-flex align-items-center" style="height: 550px">
      <div class="container" data-aos="fade-up">

        <?php
          include "../config/koneksi.php";
          $nis = $_GET['n'];
          $sql_cek=mysqli_query($db,"SELECT * FROM data_pemili WHERE nis='".$nis."'");
          $tampil=mysqli_fetch_array($sql_cek);
        ?>
                <div class="container">
                  <div class="row">
                    <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center">
                      <h1>Uppsss,</h1>
                      <h4>NIS <?php echo $tampil['nis'] ?> sudah terdaftar atas nama <?php echo $tampil['nama']." kelas ".$tampil['kelas'] ?></h4>
                    </div>
                    <div class="col-lg-6 order-1 order-lg-2  text-center">
                      <img src="../assets/img/Ups.png" class="img-fluid animated" alt="" width="170px">
                    </div>
                  </div>
                </div>

      </div>
    </section><!-- End Services Section -->

<?php include 'footer.php'; ?>