<?php
	include "../config/koneksi.php";

	$nis=$_POST['nis'];
	$nama=$_POST['nama'];
    $kelas=$_POST['kelas'];
    $visi=$_POST['visi'];
    $misi=$_POST['misi'];
    $nomor_urut=$_POST['nomor_urut'];

      $ubah_pemilih = mysqli_query($db,"UPDATE `kandidat` SET `nomor_urut` = '$nomor_urut', `nama` = '$nama', `kelas` = '$kelas', `visi` = '$visi', `misi` = '$misi' where nis = '$nis'");

        if($ubah_pemilih){
              header("Location: kandidat.php");
        }else{
                echo 'Simpan Gagal';
        }
?>