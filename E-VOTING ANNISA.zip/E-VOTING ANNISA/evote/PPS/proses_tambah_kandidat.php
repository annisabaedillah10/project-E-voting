<?php
	include "../config/koneksi.php";

	$nis=$_POST['nis'];
	$nama=$_POST['nama'];
    $kelas=$_POST['kelas'];
    $visi=$_POST['visi'];
    $misi=$_POST['misi'];
    $nomor_urut=$_POST['nomor_urut'];

	$ekstensi_diperbolehkan = array('png','jpg','jpeg');
    $nama_file = $_FILES['file']['name'];
    $x = explode('.', $nama_file);
    $ekstensi = strtolower(end($x));
    $ukuran_file  = $_FILES['file']['size'];
    $file_tmp = $_FILES['file']['tmp_name'];  

    if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){
      if($ukuran_file < 1044070){     
      move_uploaded_file($file_tmp, '../assets/img/team/'.$nama_file);        
      $tambah_pemilih = mysqli_query($db,"INSERT INTO `kandidat` (`nomor_urut`, `nis`, `nama`, `kelas`, `visi`, `misi`, `foto` ) VALUES ('$nomor_urut', '$nis','$nama','$kelas','$visi','$misi','$nama_file')");

        if($tambah_pemilih){
              header("Location: kandidat.php");
        }else{
                echo 'Simpan Gagal';
        }
       }else{
            echo 'Ukuran Terlalu Besar';
       }
    }else{
        echo 'Format File Salah';
    }
?>