<?php
	include "../config/koneksi.php";

	$nis=$_POST['nis'];

	$ekstensi_diperbolehkan = array('png','jpg','jpeg');
    $nama_file = $_FILES['file']['name'];
    $x = explode('.', $nama_file);
    $ekstensi = strtolower(end($x));
    $ukuran_file  = $_FILES['file']['size'];
    $file_tmp = $_FILES['file']['tmp_name'];  

    if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){
      if($ukuran_file < 1044070){     
      move_uploaded_file($file_tmp, '../assets/img/team/'.$nama_file);        
      $ubah_foto_pemilih = mysqli_query($db,"UPDATE `kandidat` SET `foto` = '$nama_file' WHERE nis = '$nis'");

        if($ubah_foto_pemilih){
              header("Location: kandidat.php");
        }else{
                echo 'Simpan Gagal';
        }
       }else{
            echo 'Ukuran Terlalu Besar';
       }
    }else{
        echo 'Format File Salah';
    }
?>