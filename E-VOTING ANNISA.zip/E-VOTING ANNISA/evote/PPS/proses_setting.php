<?php
	include "../config/koneksi.php";

	$status_tps=$_POST['status_tps'];
	$waktu_buka=$_POST['waktu_buka'];
	$waktu_tutup=$_POST['waktu_tutup'];

	$sql = "UPDATE `setting` SET status_tps = '$status_tps', waktu_buka = '$waktu_buka', waktu_tutup = '$waktu_tutup' where kode_setting='1'";
	$data = mysqli_query($db,$sql);

	if ($data) {
		if ($status_tps == 'Dibuka') {

			$sql4 = "SELECT * FROM setting";
	        $data4 = mysqli_query($db,$sql4);      
	        $tampil4 = mysqli_fetch_array($data4);

	        $waktu_buka = $tampil4['waktu_buka'];
	        $waktu_tutup = $tampil4['waktu_tutup'];

			$sql2 = "SELECT * FROM `data_pemili` as a inner join surat_suara as b on a.nis=b.nis where b.keterangan='mutakhir'";
            $data2 = mysqli_query($db,$sql2);      
            while($tampil2 = mysqli_fetch_array($data2)){

	            $email = $tampil2['email'];
	            $nis = $tampil2['nis'];
	            $kode_surat_suara = $tampil2['kode_surat_suara'];
	            
				$token=crypt("$nis", "micin"); //generste token fungs crypt

				mysqli_query($db,"UPDATE `surat_suara` SET token = '$token' where kode_surat_suara='$kode_surat_suara'");

				//include kirim email
                include("mail.php");
             }
		}else{

		}

	    header("Location: index.php?p=1");
	}else{
		header("Location: index.php?p=0");
	}
?>