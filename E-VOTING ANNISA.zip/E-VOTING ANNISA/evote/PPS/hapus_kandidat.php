<?php
include '../config/koneksi.php';
$nis = $_GET['nis'];

    $sql = "DELETE from `kandidat`where nis='$nis'";
    $query = mysqli_query($db, $sql);
    if ($query) {
        echo "<script>window.alert('Berhasil menghapus data kandidat');
        window.location=(href='kandidat.php')</script>";
    } else {
        echo "<script>window.alert('Gagal, ada kesalahan saat menghapus data kandidat di dalam database');
		window.location=(href='kandidat.php')</script>";
    }