<?php
    include "../config/koneksi.php";

    $nis=$_POST['nis'];
    $nama=$_POST['nama'];
    $kelas=$_POST['kelas'];
    $jabatan=$_POST['jabatan'];
    $password=$_POST['password'];


        $ubah_pemilih = mysqli_query($db,"UPDATE `pps` SET `nama` = '$nama', `jabatan` = '$jabatan', `kelas`='$kelas', `password`='$password' where nis = $nis");

        if ($ubah_pemilih) {
            header("Location: pps.php");
        }else{
            header("Location: notifikasi.php?p=0");
        }
?>