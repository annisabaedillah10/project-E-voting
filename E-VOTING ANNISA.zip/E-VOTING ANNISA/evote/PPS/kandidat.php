<?php include 'header.php'; ?>

    <!-- ======= Services Section ======= -->
    <section id="services" class="services section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Data Kandidat</h2>
          <p style="font-size: 19px">Pemilihan Ketua OSIS Periode 2023-2024</p>
        <a href="tambah_kandidat.php" class="btn btn-primary">Tambah</a> <br>
        </div>

        <div class="row">

        <?php
          $sql = "SELECT * FROM `kandidat`";
          $data = mysqli_query($db,$sql);      
          while($tampil = mysqli_fetch_array($data)){
        ?>

          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-box">
              <h4 class="title"><a href="">No. <?php echo $tampil['nomor_urut']?></a></h4>
              <div class="icon"><img src="../assets/img/team/<?php echo $tampil['foto']?>" height="250px" width="100%"></div>
              <p class="description"><b><?php echo $tampil['nama']?></b><br><?php echo $tampil['nis']?></p>
              <a href="ubah_kandidat.php?nis=<?php echo $tampil['nis']?>" class="btn btn-primary"><i class="bx bx-pencil" style="color: white"></i></a> <a href="ubah_foto_kandidat.php?nis=<?php echo $tampil['nis']?>" class="btn btn-warning"><i class="bx bx-image" style="color: white"></i></a> <a href="hapus_kandidat.php?nis=<?php echo $tampil['nis']?>" class="btn btn-danger"><i class="bx bx-trash" style="color: white"></i></a>
              <p class="description" style="text-align: left"><b>Visi :</b><br> <?php echo $tampil['visi']?></p>
              <p class="description" style="text-align: left"><b>Misi :</b><br> <?php echo $tampil['misi']?></p>
            </div>
          </div>

        <?php } ?>

        </div>

      </div>
    </section><!-- End Services Section -->

 
<?php include 'footer.php'; ?>