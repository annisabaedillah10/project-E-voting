<?php
	include "../config/koneksi.php";
		$sql4 = "SELECT * FROM `setting`";
        $data4 = mysqli_query($db,$sql4);      
        $tampil4 = mysqli_fetch_array($data4);

        $waktu_buka = $tampil4['waktu_buka'];
        $waktu_tutup = $tampil4['waktu_tutup'];

			$sql2 = "SELECT * FROM `data_pemili` as a inner join surat_suara as b on a.nis=b.nis where b.keterangan = 'terdaftar'";
            $data2 = mysqli_query($db,$sql2);      
            while($tampil2 = mysqli_fetch_array($data2)){

	            $nis = $tampil2['nis'];
	            $nama = $tampil2['nama'];
	            $email = $tampil2['email'];
	            $kode_surat_suara = $tampil2['kode_surat_suara'];
	            
				$token=crypt("$nis", "garam"); //geenerate token

				mysqli_query($db,"UPDATE `surat_suara` SET token = '$token' where kode_surat_suara='$kode_surat_suara'");

				//include kirim email
                include("mail2.php");
             
		}

		header("Location:pemutakhiran_data_pemilih.php");
?>