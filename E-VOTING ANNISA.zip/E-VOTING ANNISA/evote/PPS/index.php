<?php include 'header.php'; ?>

    <section id="about" class="about">
      <div class="container">

        <div class="row justify-content-between">
          <div class="col-lg-5 d-flex align-items-center justify-content-center about-img">
            <img src="../assets/img/about-img.svg" class="img-fluid" alt="" data-aos="zoom-in">
          </div>
          <div class="col-lg-6 pt-5 pt-lg-0">
            <h3 data-aos="fade-up">Panitia Pemungutan Suara (PPS)</h3>
            <p data-aos="fade-up" data-aos-delay="100">
              Selamat datang <?php echo $r_cek['nama'];?>, Panitia Pemungutan Suara pada Pemilihan Ketua OSIS SMA Negeri 1 Warungkiara periode 2022-2023
            </p>
            <div class="row">
              <?php 
                $pesan = isset($_GET['p']) ? $_GET['p'] : '';

                if ($pesan=='1') {
              ?> <div class="alert alert-success" data-aos="fade-up" data-aos-delay="100"><b>Berhasil,</b> Status TPS berhasil diubah !</div>
              <?php
                 }elseif ($pesan=='0') {
              ?> <div class="alert alert-danger" data-aos="fade-up" data-aos-delay="100"><b>Gagal,</b> Status TPS belum berubah !</div>
              <?php
                 }else{

                 }
              ?>

                <?php
                  $sql = "SELECT * FROM `setting`";
                  $data = mysqli_query($db,$sql);      
                  $tampil = mysqli_fetch_array($data);
                ?>
              <div class="col-md-6" data-aos="fade-up" >
                <i class="bx bx-receipt"></i>
                <h4>Tahap Sekarang :</h4>
                <p>
                  <?php
                    if ($tampil['status_tps']=='Belum Dibuka') {
                      echo "- <b>TPS Belum Dibuka</b> <br>- Pemutakhiran Data Pemilih";
                    }elseif ($tampil['status_tps']=='Dibuka') {
                      echo "- <b>TPS Dibuka</b> <br>- Pemungutan Suara Sedang Berlangsung";
                    }if ($tampil['status_tps']=='Sudah Ditutup') {
                      echo "- <b>TPS Sudah Ditutup</b> <br>- Pengumuman Hasil Pemilihan";
                    }
                  ?>
                </p>
              </div>
              <div class="col-md-6" data-aos="fade-up" data-aos-delay="200">
                <i class="bx bx-cube-alt"></i>
                <h4>Tindakan :</h4>
                <p>
                  <?php
                    if ($tampil['status_tps']=='Belum Dibuka') {
                      echo "- Input Data Kandidat <br>- Input Data Pemilih <br>- Pemutakhiran Data Pemilih";
                    }elseif ($tampil['status_tps']=='Dibuka') {
                      echo "- Monitoring Data Pemilih Yang Sudah Menggunakan Hak pilihnya";
                    }if ($tampil['status_tps']=='Sudah Ditutup') {
                      echo "- Lihat Hasil Perhitungan Suara";
                    }
                  ?>
                </p>
              </div>
              <p data-aos="fade-up" data-aos-delay="300">Waktu Buka TPS : <?php echo $tampil['waktu_buka']." s/d ".$tampil['waktu_tutup'] ?></p>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End About Section -->

    <br><br><br>

 
<?php include 'footer.php'; ?>