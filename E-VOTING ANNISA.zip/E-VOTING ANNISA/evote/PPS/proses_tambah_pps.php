<?php
	include "../config/koneksi.php";

	$nis=$_POST['nis'];
	$nama=$_POST['nama'];
    $kelas=$_POST['kelas'];
    $jabatan=$_POST['jabatan'];
    $password=$_POST['password'];

	$sql_cek=mysqli_query($db,"SELECT * FROM pps WHERE nis='".$nis."'");
    $jml_data=mysqli_num_rows($sql_cek);

    if ($jml_data=='1') {
        header("Location: notifikasi.php?p=98");    	
    }else{
    	$tambah_pemilih = mysqli_query($db,"INSERT INTO `pps` (`nis`, `nama`, `jabatan`, `kelas`, `password`) VALUES ('$nis','$nama','$jabatan','$kelas','$password')");

            header("Location: pps.php");

    }
?>