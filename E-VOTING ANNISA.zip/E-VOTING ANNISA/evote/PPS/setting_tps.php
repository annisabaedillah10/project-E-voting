 <?php include 'header.php'; ?>

  <!-- ======= Contact Us Section ======= -->
    <section id="contact" class="contact">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <p>Setting TPS</p>
        </div>

        <div class="row">

          <div class="col-lg-3 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
            
          </div>

          <div class="col-lg-6 mt-5 mt-lg-0 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="200">
            <form action="proses_setting.php" method="post" role="form">
              <div class="row">
                <?php
                  $sql = "SELECT * FROM `setting`";
                  $data = mysqli_query($db,$sql);      
                  $tampil = mysqli_fetch_array($data);
                ?>
                <div class="form-group col-md-12">
                  <label for="name" style="margin-top: 15px">Status TPS</label>
                  <select name="status_tps" class="form-control" id="name" required>
                    <option value="<?php echo $tampil['status_tps'] ?>" name="status_tps"><b><?php echo $tampil['status_tps'] ?></b></option>
                    <option value="Belum Dibuka" name="status_tps">Belum Dibuka</option>
                    <option value="Dibuka" name="status_tps">Dibuka</option>
                    <option value="Sudah Ditutup" name="status_tps">Sudah Ditutup</option>
                  </select>
                </div>
                <div class="form-group col-md-6">
                  <label for="name" style="margin-top: 15px">Waktu Buka</label>
                  <input type="datetime-local" name="waktu_buka" class="form-control" required value="<?php echo $tampil['waktu_buka'] ?>">
                </div>
                <div class="form-group col-md-6">
                  <label for="name" style="margin-top: 15px">Waktu Tutup</label>
                  <input type="datetime-local" name="waktu_tutup" class="form-control" required value="<?php echo $tampil['waktu_tutup'] ?>">
                </div>
              </div>
              <div class="text-center" style="margin-top: 15px"><button type="submit" class="btn btn-primary" style="color: white; background-color: #EB5D1E; border-radius: 60px; margin-left: 25px; margin-right: 25px">SIMPAN</button></div>
            </form>
          </div>

        </div>

      </div>
    </section><!-- End Contact Us Section -->

<?php include 'footer.php'; ?>