 <?php include 'header.php'; ?>

  <!-- ======= Contact Us Section ======= -->
    <section id="contact" class="contact">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <p>FORM TAMBAH DATA PEMILIH</p>
        </div>

        <div class="row">

          <div class="col-lg-3 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
            
          </div>

          <div class="col-lg-6 mt-5 mt-lg-0 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="200">
            <form action="proses_tambah_pemilih.php" method="post" role="form">
              <div class="row">
                <div class="form-group col-md-6">
                  <label for="name" style="margin-top: 15px">Nama</label>
                  <input type="text" name="nama" class="form-control" required>
                </div>
                <div class="form-group col-md-6">
                  <label for="name" style="margin-top: 15px">NIS</label>
                  <input type="number" name="nis" class="form-control" required>
                </div>
                <div class="form-group col-md-12">
                  <label for="name" style="margin-top: 15px">Jenis Kelamin</label>
                  <select name="jenis_kelamin" class="form-control" id="kelas" required>
                    <option value="Laki-laki" name="jenis_kelamin">Laki-laki</option>
                    <option value="Perempuan" name="jenis_kelamin">Perempuan</option>
                  </select>
                </div>
                <div class="form-group col-md-12">
                  <label for="kelas" style="margin-top: 15px">Kelas</label>
                  <select name="kelas" class="form-control" required>
                    <option value="10 IPA 1" name="kelas">10 IPA 1</option>
                    <option value="10 IPA 2" name="kelas">10 IPA 2</option>
                    <option value="10 IPA 3" name="kelas">10 IPA 3</option>
                    <option value="10 IPS 1" name="kelas">10 IPS 1</option>
                    <option value="10 IPS 2" name="kelas">10 IPS 2</option>
                    <option value="10 IPS 3" name="kelas">10 IPS 3</option>
                    <option value="11 IPA 1" name="kelas">11 IPA 1</option>
                    <option value="11 IPA 2" name="kelas">11 IPA 2</option>
                    <option value="11 IPA 3" name="kelas">11 IPA 3</option>
                    <option value="11 IPS 1" name="kelas">11 IPS 1</option>
                    <option value="11 IPS 2" name="kelas">11 IPS 2</option>
                    <option value="11 IPS 3" name="kelas">11 IPS 3</option>
                    <option value="12 IPA 1" name="kelas">12 IPA 1</option>
                    <option value="12 IPA 2" name="kelas">12 IPA 2</option>
                    <option value="12 IPA 3" name="kelas">12 IPA 3</option>
                    <option value="12 IPS 1" name="kelas">12 IPS 1</option>
                    <option value="12 IPS 2" name="kelas">12 IPS 2</option>
                    <option value="12 IPS 3" name="kelas">12 IPS 3</option>
                  </select>
                </div>
                <div class="form-group col-md-6">
                  <label for="name" style="margin-top: 15px">Email</label>
                  <input type="email" name="email" class="form-control" required>
                </div>
              </div>
              <div class="text-center" style="margin-top: 15px"><button type="submit" class="btn btn-primary" style="color: white; background-color: #EB5D1E; border-radius: 60px; margin-left: 25px; margin-right: 25px">SIMPAN</button></div>
            </form>
          </div>

        </div>

      </div>
    </section><!-- End Contact Us Section -->

<?php include 'footer.php'; ?>