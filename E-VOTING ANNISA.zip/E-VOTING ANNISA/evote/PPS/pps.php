<?php include 'header.php'; ?>

    <!-- ======= Services Section ======= -->
    <section id="services" class="services section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Data Anggota PPS</h2>
          <p style="font-size: 19px">Pemilihan Ketua OSIS Periode 2023-2024</p>
          <a href="tambah_pps.php" class="btn btn-primary">Tambah</a> <br>
        </div>

          <div class="table-responsive">
            <table id="tabel-data" class="table table-striped table-bordered" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th>No.</th>
                  <th>NIS</th>
                  <th>Nama</th>
                  <th>Kelas</th>
                  <th>jabatan</th>
                  <th>password</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                 <?php
                    $nomor=0;
                    $sql = "SELECT * FROM `pps`";
                    $data = mysqli_query($db,$sql);      
                    while($tampil = mysqli_fetch_array($data)){
                  ?>

                  <tr>
                    <td><?php echo $nomor = $nomor + 1; ?></td>
                    <td><?php echo $tampil['nis']?></td>
                    <td><?php echo $tampil['nama']?></td>
                    <td><?php echo $tampil['kelas']?></td>
                    <td><?php echo $tampil['jabatan']?></td>
                    <td><?php echo $tampil['password']?></td>
                    <td><a href="ubah_pps.php?n=<?php echo $tampil['nis'];?>" class="btn btn-info btn-sm"><i class="bx bx-pencil" style="color: white"></i></a> <a href="hapus_pps.php?n=<?php echo $tampil['nis'];?>" class="btn btn-danger btn-sm"><i class="bx bx-trash" style="color: white"></i></a></td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>

      </div>
    </section><!-- End Services Section -->

 
<?php include 'footer.php'; ?>