<?php
  include "config/koneksi.php";
  $sql = "SELECT * FROM `setting`";
  $data = mysqli_query($db,$sql);      
  $tampil = mysqli_fetch_array($data);

  if ($tampil['status_tps']=='Dibuka') {
	$token=$_POST['token'];
	$nomor_urut=$_POST['nomor_urut'];

	$sql_cek=mysqli_query($db,"SELECT * FROM surat_suara WHERE token='".$token."' and keterangan='mutakhir'");
    $jml_data=mysqli_num_rows($sql_cek);

    if ($jml_data=='1') {
    	$tambah_suara = mysqli_query($db,"INSERT INTO `kotak_suara` (`kode_pilih`, `keterangan_waktu`, `nomor_urut`) VALUES (NULL, NULL, '$nomor_urut')");

    	if ($tambah_suara) {
    		$sql = "UPDATE `surat_suara` SET keterangan = 'sudah memilih' where token='$token'";
			$data = mysqli_query($db,$sql);

			header("Location: notifikasi.php?p=1");
    	}else{
    		header("Location: notifikasi.php?p=0");
    	}
    	
    }else{
    	header("Location: notifikasi.php?p=99");
    }
  }elseif ($tampil['status_tps']=='Belum Dibuka'){
    header("Location: notifikasi.php?p=65");
  }elseif ($tampil['status_tps']=='Sudah Ditutup'){
    header("Location: notifikasi.php?p=66");
  }
?>