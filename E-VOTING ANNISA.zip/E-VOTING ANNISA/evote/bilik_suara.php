<?php
  include "config/koneksi.php";

  $sql = "SELECT * FROM `setting`";
  $data = mysqli_query($db,$sql);      
  $tampil = mysqli_fetch_array($data);

  if ($tampil['status_tps']=='Dibuka') {
    $token = $_GET['t'];
    $sql_cek=mysqli_query($db,"SELECT * FROM surat_suara WHERE token='".$token."' and keterangan='mutakhir'");
    $jml_data=mysqli_num_rows($sql_cek);

    if ($jml_data=='1') {

    }else{
      header("Location: notifikasi.php?p=99");
    }
  }elseif ($tampil['status_tps']=='Belum Dibuka'){
    header("Location: notifikasi.php?p=65");
  }elseif ($tampil['status_tps']=='Sudah Ditutup'){
    header("Location: notifikasi.php?p=66");
  }
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Pemilihan Ketua OSIS</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  
  <script src="https://code.jquery.com/jquery-3.1.0.js"></script>
  <script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Ninestars - v4.7.0
  * Template URL: https://bootstrapmade.com/ninestars-free-bootstrap-3-theme-for-creative/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  
  <main id="main">


    <!-- ======= Services Section ======= -->
    <section id="services" class="services section-bg" style="margin-top: -85px">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>SURAT SUARA</h2>
          <p style="font-size: 19px">Pasangan Calon Ketua dan Wakil Ketua OSIS Periode 2023-2024</p>
        </div>

        <div class="row">

        <?php
          $sql = "SELECT * FROM `kandidat`";
          $data = mysqli_query($db,$sql);      
          while($tampil = mysqli_fetch_array($data)){
        ?>

          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-box">
              <h4 class="title"><a href="">No. <?php echo $tampil['nomor_urut']?></a></h4>
              <div class="icon"><img src="assets/img/team/<?php echo $tampil['foto']?>" width="220px" height="250px"></div>
              <p class="description"><b><?php echo $tampil['nama']?></b></p>
              <form action="proses_pilihan.php" method="post" role="form">
                <div class="row">
                  <div class="form-group col-md-6">
                    <input type="text" name="token" class="form-control" required value="<?php echo $_GET['t'] ?>" hidden  required readonly>
                    <input type="text" name="nomor_urut" class="form-control" required value="<?php echo $tampil['nomor_urut'] ?>" hidden required readonly>
                  </div>
                </div>
                <div class="text-center" style="margin-top: 15px"><button type="submit" class="btn btn-primary btn-block" style="color: white; background-color: #EB5D1E; border-radius: 15px;">PILIH</button></div>
              </form>
            </div>
          </div>

        <?php } ?>

        </div>

      </div>
    </section><!-- End Services Section -->

     <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="container py-4">
      <div class="copyright">
        Nisa Teknik Informatika 2018
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/ninestars-free-bootstrap-3-theme-for-creative/ -->
        Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="js/jquery-3.1.0.js"></script>
  <script src="js/jquery.dataTables.min.js"></script>
  <script>
    $(document).ready(function(){
        $('#tabel-data').DataTable();
    });
  </script>
  <script src="assets/js/main.js"></script>

</body>

</html>