-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 19 Jul 2022 pada 14.18
-- Versi Server: 10.1.19-MariaDB
-- PHP Version: 7.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `evote`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_pemili`
--

CREATE TABLE `data_pemili` (
  `nis` int(12) NOT NULL,
  `nama` varchar(250) NOT NULL,
  `jenis_kelamin` varchar(15) NOT NULL,
  `kelas` varchar(50) NOT NULL,
  `email` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `data_pemili`
--

INSERT INTO `data_pemili` (`nis`, `nama`, `jenis_kelamin`, `kelas`, `email`) VALUES
(262626, 'annisa', 'Perempuan', '12 IPS 2', 'annisabaedillah7@gmail.com'),
(272727, 'lili', 'Perempuan', '12 IPA 2', 'liliably07@gmail.com');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kandidat`
--

CREATE TABLE `kandidat` (
  `nomor_urut` int(6) NOT NULL,
  `nis` int(12) NOT NULL,
  `nama` varchar(250) NOT NULL,
  `kelas` varchar(50) NOT NULL,
  `visi` text NOT NULL,
  `misi` text NOT NULL,
  `foto` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kandidat`
--

INSERT INTO `kandidat` (`nomor_urut`, `nis`, `nama`, `kelas`, `visi`, `misi`, `foto`) VALUES
(1, 11111, 'Andri Taher', '12 IPA 3', 'Menjadikan OSIS SMP Negeri 234 sebagai organisasi yang bermutu dan bertanggung jawab menjadikan siswa-siswi lebih disiplin, kreatif, dan berprestasi.', '1. Mengajak siswa-siswi untuk aktif di kegiatan akademik dan non-  akademik yang diselenggarakan di sekolah maupun di luar sekolah.<br>\r\n2. Meningkatkan mutu kerja para pengurus OSIS.<br>\r\n3. Menjadi wadah aspirasi siswa-siswi SMP 234 untuk kemajuan sekolah dan organisasi OSIS.<br>\r\n4. Mengadakan kegiatan di bidang sosial dengan mengajak siswa-siswi ikut berperan.', 'team-1.jpg'),
(2, 22222, 'Santi Melawa', '12 IPA 3', 'Mewujudkan OSIS SMK Negeri 11 sebagai organisasi yang dapat bermanfaat bagi sekolah dan siswa-siswi dalam pengembangan diri dan prestasi.', '1. Mengadakan kegiatan yang melibatkan seluruh siswa-siswi.<br>\r\n2. Menumbuhkan jiwa kewirausahaan pada siswa-siswi sebagai bekal diri.<br>\r\n3. Menjadikan ekstrakurikuler sebagai sarana pengembangan potensi diri siswa-siswi.', 'DSC05651.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kotak_suara`
--

CREATE TABLE `kotak_suara` (
  `kode_pilih` int(6) NOT NULL,
  `keterangan_waktu` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `nomor_urut` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kotak_suara`
--

INSERT INTO `kotak_suara` (`kode_pilih`, `keterangan_waktu`, `nomor_urut`) VALUES
(12, '2022-06-24 18:46:59', 1),
(13, '2022-06-24 20:18:53', 1),
(14, '2022-06-25 03:02:42', 1),
(15, '2022-06-26 10:56:18', 1),
(16, '2022-06-26 13:08:22', 2),
(18, '2022-07-07 10:03:59', 2),
(19, '2022-07-07 10:04:25', 2),
(20, '2022-07-13 09:07:08', 2),
(21, '2022-07-13 12:18:25', 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pps`
--

CREATE TABLE `pps` (
  `nis` int(12) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `kelas` varchar(50) NOT NULL,
  `jabatan` varchar(100) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pps`
--

INSERT INTO `pps` (`nis`, `nama`, `kelas`, `jabatan`, `password`) VALUES
(12345, 'Sandi Krisna', '11 IPA 3', 'PPS Cabang', '12345'),
(223344, 'Nisa', '10 IPA 2', 'PPS Pusat', 'nisabae'),
(18182020, 'Sinchan', '11 IPA 3', 'PPS Cabang', 'sinchan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `setting`
--

CREATE TABLE `setting` (
  `kode_setting` int(6) NOT NULL,
  `status_tps` varchar(100) NOT NULL,
  `waktu_buka` datetime NOT NULL,
  `waktu_tutup` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `setting`
--

INSERT INTO `setting` (`kode_setting`, `status_tps`, `waktu_buka`, `waktu_tutup`) VALUES
(1, 'Dibuka', '2022-07-11 10:10:00', '2022-07-14 01:00:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `surat_suara`
--

CREATE TABLE `surat_suara` (
  `kode_surat_suara` int(11) NOT NULL,
  `nis` int(11) DEFAULT NULL,
  `token` text,
  `keterangan` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `surat_suara`
--

INSERT INTO `surat_suara` (`kode_surat_suara`, `nis`, `token`, `keterangan`) VALUES
(13, 262626, 'miZSy44Rf6sF6', 'mutakhir'),
(19, 272727, 'miBKz7rQqC1ik', 'mutakhir');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data_pemili`
--
ALTER TABLE `data_pemili`
  ADD PRIMARY KEY (`nis`);

--
-- Indexes for table `kandidat`
--
ALTER TABLE `kandidat`
  ADD PRIMARY KEY (`nomor_urut`);

--
-- Indexes for table `kotak_suara`
--
ALTER TABLE `kotak_suara`
  ADD PRIMARY KEY (`kode_pilih`),
  ADD KEY `FK_kotak_suara_kandidat` (`nomor_urut`);

--
-- Indexes for table `pps`
--
ALTER TABLE `pps`
  ADD PRIMARY KEY (`nis`);

--
-- Indexes for table `setting`
--
ALTER TABLE `setting`
  ADD PRIMARY KEY (`kode_setting`);

--
-- Indexes for table `surat_suara`
--
ALTER TABLE `surat_suara`
  ADD PRIMARY KEY (`kode_surat_suara`),
  ADD KEY `FK_surat_suara_data_pemili` (`nis`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kotak_suara`
--
ALTER TABLE `kotak_suara`
  MODIFY `kode_pilih` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `surat_suara`
--
ALTER TABLE `surat_suara`
  MODIFY `kode_surat_suara` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `kotak_suara`
--
ALTER TABLE `kotak_suara`
  ADD CONSTRAINT `FK_kotak_suara_kandidat` FOREIGN KEY (`nomor_urut`) REFERENCES `kandidat` (`nomor_urut`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `surat_suara`
--
ALTER TABLE `surat_suara`
  ADD CONSTRAINT `FK_surat_suara_data_pemili` FOREIGN KEY (`nis`) REFERENCES `data_pemili` (`nis`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
